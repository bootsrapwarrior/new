<?php
$title = 'index';
require_once 'includes/header.php';
require_once 'db/conn.php';

$results = $crud ->getSpecialties();

?>
<h1 class="text-center"> Registration for IT Conference </h1>
<form method= "POST" action = "success.php" enctype='multipart/form-data'>
    <div class="form-group">
      <label for="firstname">First Name</label>
      <input required type="text" class="form-control" id="firstname" name="firstname" placeholder="Input Firstname" required>
    </div>

    <div class="form-group">
      <label for="lastname">Last Name</label>
      <input required type="text" class="form-control" id="lastname" name="lastname" placeholder="Input Lastname" required>
    </div>

    <div class="form-group">
        <label for="dob">Date of Birth</label>
        <input type="text" class="form-control" id="dob" name="datepicker" placeholder="Your birth date" required>
    </div>
    
    <div class="form-group">
      <label for="specialty">Area of Expertise</label>
      <select class="formm-control" id= "specialty" name= "specialty">
        <?php while($ = $results ->fetch(PDO::FETCH_ASSOC)) {?> 
        <option value ='<?php echo $r ['specialty_id']?>'><?php echo $r['name'];?></option><?php}?>
        </select>
    </div>

    <div class='form-group'>
        <label for='email'> Email Address </label>
        <input required type='form-control' id='email' name='email' aria-describedby='emailHelp'>
        <small id='emailHelp' class='form-text text-muted'> We'll never share your email with others.</small>
    </div>
<br>
    <div class='custom-file'>
        <input type='file' accept='image/*' class=' custom-file-input' id='avatar' name='avatar'>
        <label class=' custom-file-label' for='avatar'> Choose file </label>
        <small id='avatar' class=' form-text text-danger'> File upload is optional</small>
    </div>
    <button type='submit' name='submit' class='btn btn-primary btn-block'>Submit </button>
        </form>

        <br>
        <br>
        <br>
        <br>
        <br>
        <?php require_once 'includes/footer.php' ?>
    
