<?php
$title = "success" ;
require_once 'includes/header.php';
require_once 'db/conn.php';
require_once 'sendemail.php';


if(isset($_POST['submit'])){
    $firstname = $_POST['firstname'];
    $laststname = $_POST['lasttname'];
    $dob = $_POST['dob'];
    $aoe = $_POST['aoe'];
    $email = $_POST['email'];
    $contact = $_POST['contact'];
    $specialtyt = $_POST['aoe'];

    $orig_file = $_FILES['avatar']['tmp_name'];
    $ext =pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION);
    $target_dir = 'uploads/';
    $destination = "$target_dir$contact.$ext";
    move_upload_file($orig_file, $destination);

    $isSuccess = $crud->insertAttendees ($firstname, $lastname, $dob, $aoe, $email, $contact );
    $specialtyName = $crud-> getSpecialtyById($specialty);

    if($isSuccess){
        SendEmail::SendMail($email, 'Welcome to IT Conference 2023', 'You have successfully registered for this year\'s IT Conference');
        include 'include/ successmessage.php';
    }
    else{
        include 'includes/errormessage.php';
    }
    }
?>

<img src='<?php echo $destination; ?>'  class= 'rounded-circle' style=' width: 20%; height: 20%'/>
<div class = 'card' style="width: 18rem">
<div class = "card-body">
    <h5 class= "card-title">
        <?php echo $_POST["firstname"].''. $_POST['lastname'];?>
</h5>
<h6 class= ' card-subtitle mb-2 text-muted'>
<p class= "card=text">
    Date of Birth: <?php echo $_POST ['dob'];?>
</p>
<p class= "card=text">
    Email Address: <?php echo $_POST ['email'];?>
</p>
<p class= "card=text">
    Contact: <?php echo $_POST ['contact'];?>
</p>

<br>
<br>
<br>
<br>
<br>

<?php require_once 'includes/footer.php'?>
