<?php
class crud{
    private $db;
    function _construct ($connn){
        $this->db = $conn;
    }

    public function insertAttendees($firstname, $lastname, $dob, $aoe, $email, $contact){
        try {
            $sql = "INSERT INTO attendee (firstname, lastname, dob, aoe, email, contact) VALUES (:firstname, :lastname, :dob, :aoe, :email, :contact, :avatar_path)";
            $stat = $this ->db->prepare($sql);
            $stat -> bindparam(':fname', $firstname);
            $stat -> bindparam(':lname', $firstname);
            $stat -> bindparam(':dob', $dob);
            $stat -> bindparam(':email', $email);
            $stat -> bindparam(':contact', $contact);
            $stat -> bindparam(':aoe', $aoe);
            $stat -> bindparam(':avatar_path', $avatar_path);

            $stat ->execute();
            return true;
        }
        catch(PDOException $e){
            echo $e ->getMessage();
            return false;
        }
    }

    public function editAttendee($id, $fname, $lname, $dob, $email, $contact, $specialty){
        try{
            $sql = "UPDATE 'attendee' SET 'firstname' =:fname, 'lastname' =:lname, 'dateofbirth' =:dob, 'emailaddress' =:email, 'contactnumber' =:contact, 'specialty_id' =:specialty WHERE attendee_id =:id";
            $stmt
            $stmt -> bindparam(':id', $id);
            $stmt -> bindparam(':fname', $firstname);
            $stmt -> bindparam(':lname', $lastname);
            $stmt -> bindparam(':dob', $bod);
            $stmt -> bindparam(':email', $email);
            $stmt -> bindparam(':contact', $contact);
            $stmt -> bindparam(':specialty', $specialty);

            $stmt->execute();
            return true; 
        }
        catch (PDOException $e){
            echo $e -> getMessage();
            return false;
        }
    }


    public function getAttendeesDetails($id){
        try{
            $sql = "SELECT * FROM attendee an inner join specialties on a.specialty_id = s.specialty_id where attendee_id = :id":
            $stmt = $this ->db -> prepare ($sql );
            $stmt -> bindparam(':id', $id);
            $stmt -> execute ();
            $result = $stmt-> fetch ();
            return $result ;
        }
        catch (PDOException $e){
            echo $e -> getMessage();
            return false;
        }
    }

    public function getAttendeesDetails($id){
        try{
            $sql = "DELETE from attendee where attendee_id = :id":
            $stmt = $this ->db -> prepare ($sql );
            $stmt -> bindparam(':id', $id);
            $stmt -> execute ();
            $result = $stmt-> fetch ();
            return $result ;
        }
        catch (PDOException $e){
            echo $e -> getMessage();
            return false;
        }
    }
    public function getSpecialties(){
        try{
            $sql = "SELECT * FROM 'specialties' ";
            $stmt = $this ->db -> prepare ($sql );
            return $result ;
        }
        catch (PDOException $e){
            echo $e -> getMessage();
            return false;
        }
    }

    public function getSpecialtyById($id){
        try{
            $sql = "SELECT * FROM 'specialties' where specialty_id = :id":
            $stmt = $this ->db -> prepare ($sql );
            $stmt -> bindparam(':id', $id);
            $stmt -> execute ();
            $result = $stmt-> fetch ();
            return $result ;
        }
        catch (PDOException $e){
            echo $e -> getMessage();
            return false;
        }
    }
}